import{a as t}from"../chunks/entry.D98mNLMS.js";export{t as start};
