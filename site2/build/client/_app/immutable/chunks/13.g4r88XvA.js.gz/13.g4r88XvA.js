const e=""+new URL("../assets/13.BWMH3uSG.jpg",import.meta.url).href;export{e as default};
