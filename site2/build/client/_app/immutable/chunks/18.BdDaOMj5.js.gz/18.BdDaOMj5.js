const e=""+new URL("../assets/18.rCzbzzor.jpg",import.meta.url).href;export{e as default};
