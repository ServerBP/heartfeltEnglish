const e=""+new URL("../assets/3.Cg5C-Hdd.jpg",import.meta.url).href;export{e as default};
