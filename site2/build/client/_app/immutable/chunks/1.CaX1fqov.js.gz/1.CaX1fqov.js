const e=""+new URL("../assets/1.5_k37vG8.jpg",import.meta.url).href;export{e as default};
