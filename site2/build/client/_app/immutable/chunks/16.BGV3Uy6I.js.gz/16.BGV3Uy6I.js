const e=""+new URL("../assets/16.C2wsf9O2.jpg",import.meta.url).href;export{e as default};
