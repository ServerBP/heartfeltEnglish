const e=""+new URL("../assets/14.DH4jEhqI.jpg",import.meta.url).href;export{e as default};
