const e=""+new URL("../assets/19.D8LjnyOB.jpg",import.meta.url).href;export{e as default};
