const t="this is a test text with markdown # this is a h1 ## this is a h2",s={text:t};export{s as default,t as text};
