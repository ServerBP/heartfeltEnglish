const t=""+new URL("../assets/2.BjjptTqG.jpg",import.meta.url).href;export{t as default};
