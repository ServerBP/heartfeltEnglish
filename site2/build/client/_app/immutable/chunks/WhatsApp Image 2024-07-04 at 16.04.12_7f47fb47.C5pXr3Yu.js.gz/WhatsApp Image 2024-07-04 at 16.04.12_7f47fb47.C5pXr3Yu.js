const a=""+new URL("../assets/WhatsApp Image 2024-07-04 at 16.04.12_7f47fb47.xljAkgzc.jpg",import.meta.url).href;export{a as default};
