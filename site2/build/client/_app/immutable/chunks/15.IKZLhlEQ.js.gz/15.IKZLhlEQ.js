const e=""+new URL("../assets/15.VTRTsp18.jpg",import.meta.url).href;export{e as default};
